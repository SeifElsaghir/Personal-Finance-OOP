import json
from pathlib import Path


class FileManager:

    def __init__(
        self,
        file_path: str = "data/finance_data.json"
    ):
        self.file_path = Path(file_path)

        self.file_path.parent.mkdir(
            parents=True,
            exist_ok=True
        )

    def load_data(self) -> dict:

        if not self.file_path.exists():
            return {}

        try:
            with open(
                self.file_path,
                "r",
                encoding="utf-8"
            ) as file:

                return json.load(file)

        except json.JSONDecodeError:
            raise ValueError(
                "The JSON data file is corrupted."
            )

    def save_data(self, data: dict) -> None:

        try:
            with open(
                self.file_path,
                "w",
                encoding="utf-8"
            ) as file:

                json.dump(
                    data,
                    file,
                    indent=4
                )

        except OSError as error:
            raise OSError(
                f"Could not save data: {error}"
            )