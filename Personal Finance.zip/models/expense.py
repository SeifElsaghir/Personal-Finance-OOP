from models.transaction import Transaction


class Expense(Transaction):

    def __init__(
        self,
        transaction_id: int,
        amount: float,
        transaction_date: str,
        category: str,
        description: str = ""
    ):
        if not category.strip():
            raise ValueError(
                "Expense must have a category."
            )

        super().__init__(
            transaction_id,
            amount,
            transaction_date,
            description
        )

        self._category = category

    @property
    def category(self) -> str:
        return self._category

    @property
    def transaction_type(self) -> str:
        return "Expense"

    @property
    def signed_amount(self) -> float:
        return -self.amount

    def to_dict(self) -> dict:
        return {
            "id": self.transaction_id,
            "type": "Expense",
            "amount": self.amount,
            "date": self.transaction_date,
            "description": self.description,
            "category": self.category
        }