from datetime import datetime


class Budget:

    def __init__(
        self,
        budget_id: int,
        category: str,
        month: str,
        amount: float
    ):
        if not category.strip():
            raise ValueError(
                "Budget category is required."
            )

        if amount < 0:
            raise ValueError(
                "Budget cannot be negative."
            )

        try:
            datetime.strptime(month, "%Y-%m")
        except ValueError:
            raise ValueError(
                "Month must be in YYYY-MM format."
            )

        self._budget_id = budget_id
        self._category = category
        self._month = month
        self._amount = amount

    @property
    def budget_id(self) -> int:
        return self._budget_id

    @property
    def category(self) -> str:
        return self._category

    @property
    def month(self) -> str:
        return self._month

    @property
    def amount(self) -> float:
        return self._amount

    def to_dict(self) -> dict:
        return {
            "id": self._budget_id,
            "category": self._category,
            "month": self._month,
            "amount": self._amount
        }