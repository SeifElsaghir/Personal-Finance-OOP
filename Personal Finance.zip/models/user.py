class User:
    def __init__(self, user_id: int, name: str, email: str):
        if not name.strip():
            raise ValueError("Name cannot be empty.")

        if "@" not in email:
            raise ValueError("Invalid email address.")

        self._user_id = user_id
        self._name = name
        self._email = email
        self._accounts = []

    @property
    def user_id(self) -> int:
        return self._user_id

    @property
    def name(self) -> str:
        return self._name

    @property
    def email(self) -> str:
        return self._email

    @property
    def accounts(self):
        return self._accounts

    def add_account(self, account) -> None:
        self._accounts.append(account)

    def remove_account(self, account) -> None:
        if account in self._accounts:
            self._accounts.remove(account)

    def to_dict(self) -> dict:
        return {
            "id": self._user_id,
            "name": self._name,
            "email": self._email
        }