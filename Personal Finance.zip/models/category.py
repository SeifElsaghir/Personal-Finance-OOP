class Category:

    def __init__(self, category_id: int, name: str):
        if not name.strip():
            raise ValueError(
                "Category name cannot be empty."
            )

        self._category_id = category_id
        self._name = name

    @property
    def category_id(self) -> int:
        return self._category_id

    @property
    def name(self) -> str:
        return self._name

    @name.setter
    def name(self, value: str):
        if not value.strip():
            raise ValueError(
                "Category name cannot be empty."
            )

        self._name = value

    def to_dict(self) -> dict:
        return {
            "id": self._category_id,
            "name": self._name
        }