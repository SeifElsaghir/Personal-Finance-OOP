class Account:
    def __init__(
        self,
        account_id: int,
        name: str,
        currency: str = "EGP"
    ):
        if not name.strip():
            raise ValueError("Account name cannot be empty.")

        self._account_id = account_id
        self._name = name
        self._currency = currency
        self._transactions = []

    @property
    def account_id(self) -> int:
        return self._account_id

    @property
    def name(self) -> str:
        return self._name

    @property
    def currency(self) -> str:
        return self._currency

    @property
    def transactions(self):
        return self._transactions

    def add_transaction(self, transaction) -> None:
        self._transactions.append(transaction)

    def remove_transaction(self, transaction_id: int) -> bool:
        for transaction in self._transactions:
            if transaction.transaction_id == transaction_id:
                self._transactions.remove(transaction)
                return True

        return False

    def calculate_balance(self) -> float:
        balance = 0

        for transaction in self._transactions:
            balance += transaction.signed_amount

        return balance

    def to_dict(self) -> dict:
        return {
            "id": self._account_id,
            "name": self._name,
            "currency": self._currency
        }