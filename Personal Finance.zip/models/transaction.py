from abc import ABC, abstractmethod
from datetime import datetime


class Transaction(ABC):

    def __init__(
        self,
        transaction_id: int,
        amount: float,
        transaction_date: str,
        description: str = ""
    ):
        if amount <= 0:
            raise ValueError(
                "Transaction amount must be positive."
            )

        try:
            datetime.strptime(transaction_date, "%Y-%m-%d")
        except ValueError:
            raise ValueError(
                "Date must be in YYYY-MM-DD format."
            )

        self._transaction_id = transaction_id
        self._amount = amount
        self._transaction_date = transaction_date
        self._description = description

    @property
    def transaction_id(self) -> int:
        return self._transaction_id

    @property
    def amount(self) -> float:
        return self._amount

    @property
    def transaction_date(self) -> str:
        return self._transaction_date

    @property
    def description(self) -> str:
        return self._description

    @property
    @abstractmethod
    def transaction_type(self) -> str:
        pass

    @property
    @abstractmethod
    def signed_amount(self) -> float:
        pass

    @abstractmethod
    def to_dict(self) -> dict:
        pass