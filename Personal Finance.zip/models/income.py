from models.transaction import Transaction


class Income(Transaction):

    @property
    def transaction_type(self) -> str:
        return "Income"

    @property
    def signed_amount(self) -> float:
        return self.amount

    def to_dict(self) -> dict:
        return {
            "id": self.transaction_id,
            "type": "Income",
            "amount": self.amount,
            "date": self.transaction_date,
            "description": self.description,
            "category": ""
        }