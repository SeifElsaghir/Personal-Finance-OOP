import customtkinter as ctk
from tkinter import messagebox, ttk
from datetime import date

from services.finance_manager import FinanceManager
from models.income import Income
from models.expense import Expense


class FinanceApp(ctk.CTk):

    def __init__(self):
        super().__init__()

        self.manager = FinanceManager()

        self.title(
            "Personal Finance Manager"
        )

        self.geometry(
            "1200x750"
        )

        self.minsize(
            1000,
            650
        )

        self.create_sidebar()

        self.content_frame = ctk.CTkFrame(
            self,
            corner_radius=0
        )

        self.content_frame.pack(
            side="right",
            fill="both",
            expand=True
        )

        self.show_dashboard()

    # ==================================
    # SIDEBAR
    # ==================================

    def create_sidebar(self):

        sidebar = ctk.CTkFrame(
            self,
            width=220,
            corner_radius=0
        )

        sidebar.pack(
            side="left",
            fill="y"
        )

        sidebar.pack_propagate(False)

        title = ctk.CTkLabel(
            sidebar,
            text="Personal Finance",
            font=ctk.CTkFont(
                size=22,
                weight="bold"
            )
        )

        title.pack(
            pady=30
        )

        buttons = [
            ("Dashboard", self.show_dashboard),
            ("Transactions", self.show_transactions),
            ("Categories", self.show_categories),
            ("Budgets", self.show_budgets)
        ]

        for text, command in buttons:

            button = ctk.CTkButton(
                sidebar,
                text=text,
                command=command,
                height=40
            )

            button.pack(
                fill="x",
                padx=20,
                pady=7
            )

        exit_button = ctk.CTkButton(
            sidebar,
            text="Exit",
            command=self.destroy
        )

        exit_button.pack(
            side="bottom",
            fill="x",
            padx=20,
            pady=25
        )

    # ==================================
    # CLEAR CONTENT
    # ==================================

    def clear_content(self):

        for widget in (
            self.content_frame.winfo_children()
        ):

            widget.destroy()

    # ==================================
    # DASHBOARD
    # ==================================

    def show_dashboard(self):

        self.clear_content()

        title = ctk.CTkLabel(
            self.content_frame,
            text="Dashboard",
            font=ctk.CTkFont(
                size=28,
                weight="bold"
            )
        )

        title.pack(
            anchor="w",
            padx=30,
            pady=(30, 5)
        )

        balance = self.manager.get_balance()

        card = ctk.CTkFrame(
            self.content_frame
        )

        card.pack(
            fill="x",
            padx=30,
            pady=20
        )

        ctk.CTkLabel(
            card,
            text="Current Balance",
            font=ctk.CTkFont(
                size=18
            )
        ).pack(
            pady=(20, 5)
        )

        ctk.CTkLabel(
            card,
            text=f"{balance:,.2f} EGP",
            font=ctk.CTkFont(
                size=32,
                weight="bold"
            )
        ).pack(
            pady=(0, 20)
        )

        month = date.today().strftime(
            "%Y-%m"
        )

        summary = self.manager.monthly_summary(
            month
        )

        summary_frame = ctk.CTkFrame(
            self.content_frame
        )

        summary_frame.pack(
            fill="x",
            padx=30,
            pady=10
        )

        ctk.CTkLabel(
            summary_frame,
            text=f"Monthly Summary — {month}",
            font=ctk.CTkFont(
                size=20,
                weight="bold"
            )
        ).pack(
            pady=15
        )

        ctk.CTkLabel(
            summary_frame,
            text=(
                f"Income: "
                f"{summary['income']:,.2f} EGP\n\n"
                f"Expenses: "
                f"{summary['expenses']:,.2f} EGP\n\n"
                f"Net: "
                f"{summary['balance']:,.2f} EGP"
            ),
            font=ctk.CTkFont(
                size=16
            )
        ).pack(
            pady=(0, 20)
        )

    # ==================================
    # TREEVIEW
    # ==================================

    def create_treeview(
        self,
        columns
    ):

        frame = ctk.CTkFrame(
            self.content_frame
        )

        frame.pack(
            fill="both",
            expand=True,
            padx=30,
            pady=15
        )

        tree = ttk.Treeview(
            frame,
            columns=columns,
            show="headings"
        )

        for column in columns:

            tree.heading(
                column,
                text=column
            )

            tree.column(
                column,
                width=120
            )

        tree.pack(
            fill="both",
            expand=True,
            padx=10,
            pady=10
        )

        return tree

    # ==================================
    # TRANSACTIONS
    # ==================================

    def show_transactions(self):

        self.clear_content()

        ctk.CTkLabel(
            self.content_frame,
            text="Transactions",
            font=ctk.CTkFont(
                size=28,
                weight="bold"
            )
        ).pack(
            anchor="w",
            padx=30,
            pady=(25, 15)
        )

        toolbar = ctk.CTkFrame(
            self.content_frame
        )

        toolbar.pack(
            fill="x",
            padx=30
        )

        search_entry = ctk.CTkEntry(
            toolbar,
            placeholder_text="Search transactions..."
        )

        search_entry.pack(
            side="left",
            fill="x",
            expand=True,
            padx=10,
            pady=10
        )

        category_names = [
            "All"
        ]

        category_names += [
            category.name
            for category in self.manager.categories
        ]

        category_box = ctk.CTkComboBox(
            toolbar,
            values=category_names
        )

        category_box.set("All")

        category_box.pack(
            side="left",
            padx=10
        )

        ctk.CTkButton(
            toolbar,
            text="Add Income",
            command=lambda:
                self.transaction_form("Income")
        ).pack(
            side="left",
            padx=5
        )

        ctk.CTkButton(
            toolbar,
            text="Add Expense",
            command=lambda:
                self.transaction_form("Expense")
        ).pack(
            side="left",
            padx=5
        )

        tree = self.create_treeview(
            [
                "ID",
                "Type",
                "Amount",
                "Date",
                "Category",
                "Description"
            ]
        )

        def refresh():

            for item in tree.get_children():
                tree.delete(item)

            search_text = (
                search_entry.get().strip()
            )

            if search_text:

                transactions = (
                    self.manager.search_transactions(
                        search_text
                    )
                )

            else:

                transactions = (
                    self.manager.filter_by_category(
                        category_box.get()
                    )
                )

            for transaction in transactions:

                if isinstance(
                    transaction,
                    Expense
                ):

                    category = (
                        transaction.category
                    )

                else:

                    category = ""

                tree.insert(
                    "",
                    "end",
                    values=(
                        transaction.transaction_id,
                        transaction.transaction_type,
                        f"{transaction.amount:,.2f}",
                        transaction.transaction_date,
                        category,
                        transaction.description
                    )
                )

        search_entry.bind(
            "<KeyRelease>",
            lambda event: refresh()
        )

        category_box.configure(
            command=lambda value: refresh()
        )

        actions = ctk.CTkFrame(
            self.content_frame
        )

        actions.pack(
            fill="x",
            padx=30,
            pady=10
        )

        def delete_selected():

            selected = tree.selection()

            if not selected:

                messagebox.showerror(
                    "Error",
                    "Please select a transaction."
                )

                return

            values = tree.item(
                selected[0],
                "values"
            )

            transaction_id = int(
                values[0]
            )

            try:

                self.manager.delete_transaction(
                    transaction_id
                )

                refresh()

            except ValueError as error:

                messagebox.showerror(
                    "Error",
                    str(error)
                )

        ctk.CTkButton(
            actions,
            text="Delete Selected",
            command=delete_selected
        ).pack(
            side="left"
        )

        refresh()

    # ==================================
    # TRANSACTION FORM
    # ==================================

    def transaction_form(
        self,
        transaction_type
    ):

        window = ctk.CTkToplevel(
            self
        )

        window.title(
            f"Add {transaction_type}"
        )

        window.geometry(
            "450x450"
        )

        ctk.CTkLabel(
            window,
            text=f"Add {transaction_type}",
            font=ctk.CTkFont(
                size=22,
                weight="bold"
            )
        ).pack(
            pady=20
        )

        amount_entry = ctk.CTkEntry(
            window,
            placeholder_text="Amount"
        )

        amount_entry.pack(
            fill="x",
            padx=40,
            pady=10
        )

        date_entry = ctk.CTkEntry(
            window,
            placeholder_text="YYYY-MM-DD"
        )

        date_entry.insert(
            0,
            date.today().isoformat()
        )

        date_entry.pack(
            fill="x",
            padx=40,
            pady=10
        )

        description_entry = ctk.CTkEntry(
            window,
            placeholder_text="Description"
        )

        description_entry.pack(
            fill="x",
            padx=40,
            pady=10
        )

        category_box = None

        if transaction_type == "Expense":

            category_box = ctk.CTkComboBox(
                window,
                values=[
                    category.name
                    for category
                    in self.manager.categories
                ]
            )

            category_box.pack(
                fill="x",
                padx=40,
                pady=10
            )

        def save():

            try:

                amount = float(
                    amount_entry.get()
                )

                transaction_date = (
                    date_entry.get()
                )

                description = (
                    description_entry.get()
                )

                if transaction_type == "Income":

                    self.manager.add_income(
                        amount,
                        transaction_date,
                        description
                    )

                else:

                    category = (
                        category_box.get()
                    )

                    self.manager.add_expense(
                        amount,
                        transaction_date,
                        category,
                        description
                    )

                messagebox.showinfo(
                    "Success",
                    "Transaction added successfully."
                )

                window.destroy()

                self.show_transactions()

            except (
                ValueError,
                OSError
            ) as error:

                messagebox.showerror(
                    "Error",
                    str(error)
                )

        ctk.CTkButton(
            window,
            text="Save",
            command=save
        ).pack(
            fill="x",
            padx=40,
            pady=25
        )

    # ==================================
    # CATEGORIES
    # ==================================

    def show_categories(self):

        self.clear_content()

        ctk.CTkLabel(
            self.content_frame,
            text="Categories",
            font=ctk.CTkFont(
                size=28,
                weight="bold"
            )
        ).pack(
            anchor="w",
            padx=30,
            pady=25
        )

        toolbar = ctk.CTkFrame(
            self.content_frame
        )

        toolbar.pack(
            fill="x",
            padx=30
        )

        name_entry = ctk.CTkEntry(
            toolbar,
            placeholder_text="Category name"
        )

        name_entry.pack(
            side="left",
            fill="x",
            expand=True,
            padx=10,
            pady=10
        )

        tree = self.create_treeview(
            ["ID", "Category"]
        )

        def refresh():

            for item in tree.get_children():
                tree.delete(item)

            for category in self.manager.categories:

                tree.insert(
                    "",
                    "end",
                    values=(
                        category.category_id,
                        category.name
                    )
                )

        def add_category():

            try:

                self.manager.add_category(
                    name_entry.get()
                )

                name_entry.delete(
                    0,
                    "end"
                )

                refresh()

            except ValueError as error:

                messagebox.showerror(
                    "Error",
                    str(error)
                )

        def delete_category():

            selected = tree.selection()

            if not selected:

                messagebox.showerror(
                    "Error",
                    "Please select a category."
                )

                return

            values = tree.item(
                selected[0],
                "values"
            )

            category_id = int(
                values[0]
            )

            try:

                self.manager.delete_category(
                    category_id
                )

                refresh()

            except ValueError as error:

                messagebox.showerror(
                    "Error",
                    str(error)
                )

        ctk.CTkButton(
            toolbar,
            text="Add",
            command=add_category
        ).pack(
            side="left",
            padx=5
        )

        ctk.CTkButton(
            toolbar,
            text="Delete",
            command=delete_category
        ).pack(
            side="left",
            padx=5
        )

        refresh()

    # ==================================
    # BUDGETS
    # ==================================

    def show_budgets(self):

        self.clear_content()

        ctk.CTkLabel(
            self.content_frame,
            text="Budgets",
            font=ctk.CTkFont(
                size=28,
                weight="bold"
            )
        ).pack(
            anchor="w",
            padx=30,
            pady=25
        )

        toolbar = ctk.CTkFrame(
            self.content_frame
        )

        toolbar.pack(
            fill="x",
            padx=30
        )

        category_box = ctk.CTkComboBox(
            toolbar,
            values=[
                category.name
                for category
                in self.manager.categories
            ]
        )

        category_box.pack(
            side="left",
            padx=5,
            pady=10
        )

        month_entry = ctk.CTkEntry(
            toolbar,
            placeholder_text="YYYY-MM"
        )

        month_entry.insert(
            0,
            date.today().strftime(
                "%Y-%m"
            )
        )

        month_entry.pack(
            side="left",
            padx=5
        )

        amount_entry = ctk.CTkEntry(
            toolbar,
            placeholder_text="Budget amount"
        )

        amount_entry.pack(
            side="left",
            padx=5
        )

        tree = self.create_treeview(
            [
                "ID",
                "Category",
                "Month",
                "Budget",
                "Spent",
                "Remaining",
                "Used %"
            ]
        )

        def refresh():

            for item in tree.get_children():
                tree.delete(item)

            for budget in self.manager.budgets:

                status = (
                    self.manager.get_budget_status(
                        budget
                    )
                )

                tree.insert(
                    "",
                    "end",
                    values=(
                        budget.budget_id,
                        budget.category,
                        budget.month,
                        f"{status['budget']:,.2f}",
                        f"{status['spent']:,.2f}",
                        f"{status['remaining']:,.2f}",
                        f"{status['percentage']:.1f}%"
                    )
                )

        def add_budget():

            try:

                self.manager.add_budget(
                    category_box.get(),
                    month_entry.get(),
                    float(
                        amount_entry.get()
                    )
                )

                amount_entry.delete(
                    0,
                    "end"
                )

                refresh()

            except ValueError as error:

                messagebox.showerror(
                    "Error",
                    str(error)
                )

        def delete_budget():

            selected = tree.selection()

            if not selected:

                messagebox.showerror(
                    "Error",
                    "Please select a budget."
                )

                return

            values = tree.item(
                selected[0],
                "values"
            )

            budget_id = int(
                values[0]
            )

            try:

                self.manager.delete_budget(
                    budget_id
                )

                refresh()

            except ValueError as error:

                messagebox.showerror(
                    "Error",
                    str(error)
                )

        ctk.CTkButton(
            toolbar,
            text="Create Budget",
            command=add_budget
        ).pack(
            side="left",
            padx=5
        )

        ctk.CTkButton(
            toolbar,
            text="Delete",
            command=delete_budget
        ).pack(
            side="left",
            padx=5
        )

        refresh()
