# Personal Finance Management System

## Project Name

Personal Finance Management System

## Project Description

A Python desktop application for managing personal finances.

The application allows users to manage income, expenses,
categories and monthly budgets.

The application uses Object-Oriented Programming,
JSON file storage and CustomTkinter for the graphical
user interface.

## Main Features

- Add income
- Add expenses
- Delete transactions
- Search transactions
- Filter transactions by category
- Create categories
- Delete categories
- Create monthly budgets
- Delete budgets
- Track budget spending
- Calculate monthly income
- Calculate monthly expenses
- Calculate balance
- Store data using JSON
- Input validation
- Exception handling
- Graphical User Interface

## Main Classes

### User

Represents the application user.

### Account

Represents the user's financial account.

### Transaction

Abstract parent class for financial transactions.

### Income

Represents money received.

### Expense

Represents money spent.

### Category

Represents an expense category.

### Budget

Represents a monthly spending budget.

### FinanceManager

Contains the application's main business logic.

### FileManager

Handles JSON file storage.

### FinanceApp

Creates the CustomTkinter graphical interface.

## OOP Concepts Used

### Classes and Objects

The application is divided into multiple classes
representing real-world concepts.

### Constructors

Classes use `__init__()` to initialize objects.

### Encapsulation

Private attributes such as `_amount`, `_name`,
and `_transactions` are used.

Properties provide controlled access to data.

### Inheritance

`Income` and `Expense` inherit from `Transaction`.

### Polymorphism

Both `Income` and `Expense` implement methods such as:

- `transaction_type`
- `signed_amount`
- `to_dict()`

Each class provides its own implementation.

### Abstraction

`Transaction` is an abstract base class using:

- `ABC`
- `@abstractmethod`

### Composition

A `User` contains an `Account`.

An `Account` contains transactions.

## Business Rules

1. Transaction amount must be positive.
2. Expense must have a category.
3. Budget cannot be negative.
4. Monthly income and expenses are calculated automatically.
5. A category cannot be deleted if an expense uses it.
6. Duplicate categories are not allowed.
7. Duplicate budgets for the same category and month are not allowed.

## File Storage

The project does not use a database.

Data is stored in:

`data/finance_data.json`

Python's JSON functionality is used to save and load data.

## GUI Framework

The application uses:

**CustomTkinter**
