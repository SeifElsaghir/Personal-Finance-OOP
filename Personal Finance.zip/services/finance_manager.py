from datetime import datetime

from models.user import User
from models.account import Account
from models.income import Income
from models.expense import Expense
from models.category import Category
from models.budget import Budget

from file_manager.file_manager import FileManager


class FinanceManager:

    def __init__(self):

        self.file_manager = FileManager()

        self.user = User(
            1,
            "Finance User",
            "user@example.com"
        )

        self.account = Account(
            1,
            "Main Account",
            "EGP"
        )

        self.user.add_account(self.account)

        self.categories = []
        self.budgets = []

        self.load_data()





    def get_next_transaction_id(self) -> int:

        if not self.account.transactions:
            return 1

        return max(
            transaction.transaction_id
            for transaction in self.account.transactions
        ) + 1

    def get_next_category_id(self) -> int:

        if not self.categories:
            return 1

        return max(
            category.category_id
            for category in self.categories
        ) + 1

    def get_next_budget_id(self) -> int:

        if not self.budgets:
            return 1

        return max(
            budget.budget_id
            for budget in self.budgets
        ) + 1




    def save_data(self):

        data = {
            "user": self.user.to_dict(),

            "transactions": [
                transaction.to_dict()
                for transaction in self.account.transactions
            ],

            "categories": [
                category.to_dict()
                for category in self.categories
            ],

            "budgets": [
                budget.to_dict()
                for budget in self.budgets
            ]
        }

        self.file_manager.save_data(data)




    def load_data(self):

        data = self.file_manager.load_data()

        if not data:
            self.create_default_categories()
            self.save_data()
            return

        user_data = data.get("user")

        if user_data:
            self.user = User(
                user_data.get("id", 1),
                user_data.get("name", "Finance User"),
                user_data.get(
                    "email",
                    "user@example.com"
                )
            )

            self.account = Account(
                1,
                "Main Account",
                "EGP"
            )

            self.user.add_account(
                self.account
            )




        for category_data in data.get(
            "categories", []
        ):

            category = Category(
                category_data["id"],
                category_data["name"]
            )

            self.categories.append(category)




        for transaction_data in data.get(
            "transactions", []
        ):

            if transaction_data["type"] == "Income":

                transaction = Income(
                    transaction_data["id"],
                    transaction_data["amount"],
                    transaction_data["date"],
                    transaction_data.get(
                        "description", ""
                    )
                )

            else:

                transaction = Expense(
                    transaction_data["id"],
                    transaction_data["amount"],
                    transaction_data["date"],
                    transaction_data["category"],
                    transaction_data.get(
                        "description", ""
                    )
                )

            self.account.add_transaction(
                transaction
            )




        for budget_data in data.get(
            "budgets", []
        ):

            budget = Budget(
                budget_data["id"],
                budget_data["category"],
                budget_data["month"],
                budget_data["amount"]
            )

            self.budgets.append(budget)




    def create_default_categories(self):

        default_categories = [
            "Food",
            "Transport",
            "Bills",
            "Shopping",
            "Entertainment"
        ]

        for name in default_categories:

            category = Category(
                self.get_next_category_id(),
                name
            )

            self.categories.append(category)



    def add_income(
        self,
        amount: float,
        transaction_date: str,
        description: str = ""
    ):

        income = Income(
            self.get_next_transaction_id(),
            amount,
            transaction_date,
            description
        )

        self.account.add_transaction(
            income
        )

        self.save_data()

        return income





    def add_expense(
        self,
        amount: float,
        transaction_date: str,
        category: str,
        description: str = ""
    ):

        if not self.category_exists(category):
            raise ValueError(
                "Category does not exist."
            )

        expense = Expense(
            self.get_next_transaction_id(),
            amount,
            transaction_date,
            category,
            description
        )

        self.account.add_transaction(
            expense
        )

        self.save_data()

        return expense




    def category_exists(
        self,
        category_name: str
    ) -> bool:

        for category in self.categories:

            if category.name.lower() == category_name.lower():
                return True

        return False

    def add_category(
        self,
        name: str
    ):

        if self.category_exists(name):
            raise ValueError(
                "Category already exists."
            )

        category = Category(
            self.get_next_category_id(),
            name
        )

        self.categories.append(category)

        self.save_data()

        return category

    def update_category(
        self,
        category_id: int,
        new_name: str
    ):

        for category in self.categories:

            if category.category_id == category_id:

                if (
                    self.category_exists(new_name)
                    and category.name.lower()
                    != new_name.lower()
                ):
                    raise ValueError(
                        "Category already exists."
                    )

                old_name = category.name

                category.name = new_name

                # Update existing expenses
                for transaction in self.account.transactions:

                    if (
                        isinstance(transaction, Expense)
                        and transaction.category
                        == old_name
                    ):
                        transaction._category = new_name

                self.save_data()

                return

        raise ValueError(
            "Category not found."
        )

    def delete_category(
        self,
        category_id: int
    ):

        for category in self.categories:

            if category.category_id == category_id:
                for transaction in self.account.transactions:

                    if (
                        isinstance(transaction, Expense)
                        and transaction.category
                        == category.name
                    ):
                        raise ValueError(
                            "Cannot delete a category "
                            "used by an expense."
                        )

                self.categories.remove(
                    category
                )

                self.save_data()

                return

        raise ValueError(
            "Category not found."
        )




    def search_transactions(
        self,
        search_text: str
    ):

        search_text = search_text.lower()

        results = []

        for transaction in self.account.transactions:

            if (
                search_text in
                transaction.description.lower()
            ):

                results.append(transaction)

            elif (
                search_text in
                transaction.transaction_type.lower()
            ):

                results.append(transaction)

            elif search_text in str(
                transaction.amount
            ):

                results.append(transaction)

            elif (
                isinstance(transaction, Expense)
                and search_text in
                transaction.category.lower()
            ):

                results.append(transaction)

        return results




    def filter_by_category(
        self,
        category_name: str
    ):

        if category_name == "All":
            return self.account.transactions

        results = []

        for transaction in self.account.transactions:

            if (
                isinstance(transaction, Expense)
                and transaction.category
                == category_name
            ):
                results.append(transaction)

        return results



    def delete_transaction(
        self,
        transaction_id: int
    ):

        success = self.account.remove_transaction(
            transaction_id
        )

        if not success:
            raise ValueError(
                "Transaction not found."
            )

        self.save_data()





    def update_transaction(
        self,
        transaction_id: int,
        amount: float,
        transaction_date: str,
        description: str,
        category: str = ""
    ):

        for index, transaction in enumerate(
            self.account.transactions
        ):

            if (
                transaction.transaction_id
                == transaction_id
            ):

                if isinstance(
                    transaction,
                    Income
                ):

                    new_transaction = Income(
                        transaction_id,
                        amount,
                        transaction_date,
                        description
                    )

                else:

                    if not category:
                        raise ValueError(
                            "Expense must have a category."
                        )

                    new_transaction = Expense(
                        transaction_id,
                        amount,
                        transaction_date,
                        category,
                        description
                    )

                self.account.transactions[index] = (
                    new_transaction
                )

                self.save_data()

                return

        raise ValueError(
            "Transaction not found."
        )




    def add_budget(
        self,
        category: str,
        month: str,
        amount: float
    ):

        if not self.category_exists(category):
            raise ValueError(
                "Category does not exist."
            )

        for budget in self.budgets:

            if (
                budget.category.lower()
                == category.lower()
                and budget.month == month
            ):
                raise ValueError(
                    "Budget already exists "
                    "for this category and month."
                )

        budget = Budget(
            self.get_next_budget_id(),
            category,
            month,
            amount
        )

        self.budgets.append(budget)

        self.save_data()

        return budget

    def delete_budget(
        self,
        budget_id: int
    ):

        for budget in self.budgets:

            if budget.budget_id == budget_id:

                self.budgets.remove(
                    budget
                )

                self.save_data()

                return

        raise ValueError(
            "Budget not found."
        )



    def monthly_summary(
        self,
        month: str
    ):

        income = 0
        expenses = 0

        for transaction in (
            self.account.transactions
        ):

            if transaction.transaction_date.startswith(
                month
            ):

                if isinstance(
                    transaction,
                    Income
                ):
                    income += transaction.amount

                elif isinstance(
                    transaction,
                    Expense
                ):
                    expenses += transaction.amount

        return {
            "income": income,
            "expenses": expenses,
            "balance": income - expenses
        }


    def get_budget_status(
        self,
        budget: Budget
    ):

        spent = 0

        for transaction in (
            self.account.transactions
        ):

            if (
                isinstance(transaction, Expense)
                and transaction.category
                == budget.category
                and transaction.transaction_date.startswith(
                    budget.month
                )
            ):

                spent += transaction.amount

        remaining = budget.amount - spent

        if budget.amount == 0:
            percentage = 0
        else:
            percentage = (
                spent / budget.amount
            ) * 100

        return {
            "budget": budget.amount,
            "spent": spent,
            "remaining": remaining,
            "percentage": percentage
        }



    def get_balance(self) -> float:

        return self.account.calculate_balance()